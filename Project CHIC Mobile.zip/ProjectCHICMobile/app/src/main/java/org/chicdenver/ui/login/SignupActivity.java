package org.chicdenver.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.chicdenver.R;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }



}