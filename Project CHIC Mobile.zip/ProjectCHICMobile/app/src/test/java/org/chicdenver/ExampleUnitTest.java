package org.chicdenver;

import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import org.chicdenver.data.model.LoggedInUser;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void something() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        LoggedInUser someUser = new LoggedInUser("someID", "Terrence Pledger", LoggedInUser.Classification.STUDENT);
        db.collection("Users").document("5550715").set(someUser);
    }
}
